/** @file SimpleMCDMA.h
 *
 * @brief Drivers for the Rx and Tx MCDMAs.
 *
 * @author Alessandro Lovesio
 *
 * COPYRIGHT NOTICE: (c) 2023 Alessandro Lovesio.  All rights reserved.
 *
 * This file is part of SimpleMCDMA.
 *
 * SimpleMCDMA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SimpleMCDMA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SimpleMCDMA.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SIMPLEMCDMA_H
#define SIMPLEMCDMA_H

#include <xparameters.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef XPAR_XSIMPLERXMCDMA_NUM_INSTANCES
#include "xsimplerxmcdma.h"
#endif

#ifdef XPAR_XSIMPLETXMCDMA_NUM_INSTANCES
#include "xsimpletxmcdma.h"
#endif

#ifdef XPAR_XSIMPLERXMCDMA_NUM_INSTANCES
#define N_RX_CHANNELS (XSIMPLERXMCDMA_S_AXI_CTRL_DEPTH_CHANNEL_DESCR_ADDR)
typedef struct {
	uint32_t addr;
	uint32_t len;
	bool enable;
	bool done;
	bool error;
	uint32_t transfered_data;
} rx_mcdma_channel_descr_t;
typedef struct {
	rx_mcdma_channel_descr_t rx_mcdma_channel_descr[N_RX_CHANNELS];
} rx_mcdma_descr_t;
typedef enum {
	RX_MCDMA_OK,
	RX_MCDMA_BUSY,
	RX_MCDMA_ERROR
} rx_mcdma_status_t;
rx_mcdma_status_t SimpleRxMCDMA_Init(uint16_t coreID);
rx_mcdma_status_t SimpleRxMCDMA_GetStatus(uint16_t coreID);
rx_mcdma_status_t SimpleRxMCDMA_Configure(uint16_t coreID, rx_mcdma_descr_t* rx_mcdma_descr);
rx_mcdma_status_t SimpleRxMCDMA_Start(uint16_t coreID);
#endif

#ifdef XPAR_XSIMPLETXMCDMA_NUM_INSTANCES
#define N_TX_CHANNELS (XSIMPLETXMCDMA_S_AXI_CTRL_DEPTH_CHANNEL_DESCR_ADDR)
typedef struct {
	uint32_t addr;
	uint32_t len;
	bool enable;
} tx_mcdma_channel_descr_t;
typedef struct {
	tx_mcdma_channel_descr_t tx_mcdma_channel_descr[N_TX_CHANNELS];
} tx_mcdma_descr_t;
typedef enum {
	TX_MCDMA_OK,
	TX_MCDMA_BUSY,
	TX_MCDMA_ERROR
} tx_mcdma_status_t;
tx_mcdma_status_t SimpleTxMCDMA_Init(uint16_t coreID);
tx_mcdma_status_t SimpleTxMCDMA_GetStatus(uint16_t coreID);
tx_mcdma_status_t SimpleTxMCDMA_Configure(uint16_t coreID, tx_mcdma_descr_t* tx_mcdma_descr);
tx_mcdma_status_t SimpleTxMCDMA_Start(uint16_t coreID);
#endif

#endif /* SIMPLEMCDMA_H */
