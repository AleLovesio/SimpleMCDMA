/** @file SimpleMCDMA.c
 *
 * @brief Drivers for the Rx and Tx MCDMAs.
 *
 * @author Alessandro Lovesio
 *
 * COPYRIGHT NOTICE: (c) 2023 Alessandro Lovesio.  All rights reserved.
 *
 * This file is part of SimpleMCDMA.
 *
 * SimpleMCDMA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SimpleMCDMA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with SimpleMCDMA.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <xparameters.h>
#include <stdint.h>
#include <stdbool.h>

#include "SimpleMCDMA.h"

#ifdef XPAR_XSIMPLERXMCDMA_NUM_INSTANCES
XSimplerxmcdma XSimplerxmcdma_instances[XPAR_XSIMPLERXMCDMA_NUM_INSTANCES];

rx_mcdma_status_t SimpleRxMCDMA_Init(uint16_t coreID)
{
	if(coreID >= XPAR_XSIMPLERXMCDMA_NUM_INSTANCES)
	{
		return RX_MCDMA_ERROR;
	}
	if(XSimplerxmcdma_Initialize(&XSimplerxmcdma_instances[coreID], coreID) != XST_SUCCESS)
	{
		return RX_MCDMA_ERROR;
	}
	XSimplerxmcdma_InterruptGlobalDisable(&XSimplerxmcdma_instances[coreID]);
	return RX_MCDMA_OK;
}
rx_mcdma_status_t SimpleRxMCDMA_GetStatus(uint16_t coreID)
{
	if(coreID >= XPAR_XSIMPLERXMCDMA_NUM_INSTANCES)
	{
		return RX_MCDMA_ERROR;
	}
	if(!XSimplerxmcdma_IsDone(&XSimplerxmcdma_instances[coreID]) && !XSimplerxmcdma_IsIdle(&XSimplerxmcdma_instances[coreID]) && !XSimplerxmcdma_IsReady(&XSimplerxmcdma_instances[coreID]))
	{
		return RX_MCDMA_BUSY;
	}
	/* TODO: Check registers on actual RX status */
	return RX_MCDMA_OK;
}
rx_mcdma_status_t SimpleRxMCDMA_Configure(uint16_t coreID, rx_mcdma_descr_t* rx_mcdma_descr)
{
	if(coreID >= XPAR_XSIMPLERXMCDMA_NUM_INSTANCES)
	{
		return RX_MCDMA_ERROR;
	}
	for(int i = 0; i < N_RX_CHANNELS; i++)
	{
		XSimplerxmcdma_Write_channel_descr_addr_Words(&XSimplerxmcdma_instances[coreID], i, &(rx_mcdma_descr->rx_mcdma_channel_descr[i].addr), 1);
		XSimplerxmcdma_Write_channel_descr_len_Words(&XSimplerxmcdma_instances[coreID], i, &(rx_mcdma_descr->rx_mcdma_channel_descr[i].len), 1);
		XSimplerxmcdma_Write_channel_descr_enable_Bytes(&XSimplerxmcdma_instances[coreID], i, &(rx_mcdma_descr->rx_mcdma_channel_descr[i].enable), 1);
	}
	return TX_MCDMA_OK;
}
rx_mcdma_status_t SimpleRxMCDMA_Start(uint16_t coreID)
{
	if(coreID >= XPAR_XSIMPLERXMCDMA_NUM_INSTANCES)
	{
		return RX_MCDMA_ERROR;
	}
	XSimplerxmcdma_Start(&XSimplerxmcdma_instances[coreID]);
	return RX_MCDMA_OK;
}
#endif

#ifdef XPAR_XSIMPLETXMCDMA_NUM_INSTANCES
XSimpletxmcdma XSimpletxmcdma_instances[XPAR_XSIMPLETXMCDMA_NUM_INSTANCES];

tx_mcdma_status_t SimpleTxMCDMA_Init(uint16_t coreID)
{
	if(coreID >= XPAR_XSIMPLETXMCDMA_NUM_INSTANCES)
	{
		return TX_MCDMA_ERROR;
	}
	if(XSimpletxmcdma_Initialize(&XSimpletxmcdma_instances[coreID], coreID) != XST_SUCCESS)
	{
		return TX_MCDMA_ERROR;
	}
	XSimpletxmcdma_InterruptGlobalDisable(&XSimpletxmcdma_instances[coreID]);
	return TX_MCDMA_OK;
}
tx_mcdma_status_t SimpleTxMCDMA_GetStatus(uint16_t coreID)
{
	if(coreID >= XPAR_XSIMPLETXMCDMA_NUM_INSTANCES)
	{
		return TX_MCDMA_ERROR;
	}
	if(!XSimpletxmcdma_IsDone(&XSimpletxmcdma_instances[coreID]) && !XSimpletxmcdma_IsIdle(&XSimpletxmcdma_instances[coreID]) && !XSimpletxmcdma_IsReady(&XSimpletxmcdma_instances[coreID]))
	{
		return TX_MCDMA_BUSY;
	}
	/* TODO: Check registers on actual RX status */
	return TX_MCDMA_OK;
}
tx_mcdma_status_t SimpleTxMCDMA_Configure(uint16_t coreID, tx_mcdma_descr_t* tx_mcdma_descr)
{
	if(coreID >= XPAR_XSIMPLETXMCDMA_NUM_INSTANCES)
	{
		return TX_MCDMA_ERROR;
	}
	for(int i = 0; i < N_RX_CHANNELS; i++)
	{
		XSimpletxmcdma_Write_channel_descr_addr_Words(&XSimpletxmcdma_instances[coreID], i, &(tx_mcdma_descr->tx_mcdma_channel_descr[i].addr), 1);
		XSimpletxmcdma_Write_channel_descr_len_Words(&XSimpletxmcdma_instances[coreID], i, &(tx_mcdma_descr->tx_mcdma_channel_descr[i].len), 1);
		XSimpletxmcdma_Write_channel_descr_enable_Bytes(&XSimpletxmcdma_instances[coreID], i, &(tx_mcdma_descr->tx_mcdma_channel_descr[i].enable), 1);
	}
	return TX_MCDMA_OK;
}
tx_mcdma_status_t SimpleTxMCDMA_Start(uint16_t coreID)
{
	if(coreID >= XPAR_XSIMPLETXMCDMA_NUM_INSTANCES)
	{
		return TX_MCDMA_ERROR;
	}
	XSimpletxmcdma_Start(&XSimpletxmcdma_instances[coreID]);
	return TX_MCDMA_OK;
}
#endif

