#include "xil_cache.h"
#include "SimpleMCDMA.h"
#include "xil_printf.h"

uint32_t __attribute__((section(".dmadata"))) mem_source[2048];
uint32_t __attribute__((section(".dmadata"))) mem_dest[2048];

int main ()
{
	rx_mcdma_descr_t rx_mcdma_descr;
	tx_mcdma_descr_t tx_mcdma_descr;
	Xil_ICacheEnable();
	Xil_DCacheEnable();


	//xil_printf("Welcome to the Simple MCDMA Test Bench!\n\r");
	for(int i = 0; i < 2048; i++)
	{
		mem_dest[i] = 0;
		mem_source[i] = i;
	}
	xil_printf("a");
	if(SimpleRxMCDMA_Init(0) != RX_MCDMA_OK || SimpleTxMCDMA_Init(0) != TX_MCDMA_OK)
	{
		//xil_printf("MCDMA Init Error!\n\r");
		xil_printf("1");
		return -1;
	}

	if(SimpleRxMCDMA_GetStatus(0) != RX_MCDMA_OK || SimpleTxMCDMA_GetStatus(0) != TX_MCDMA_OK)
	{
		//xil_printf("MCDMA Post Init Status Get error!\n\r");
		xil_printf("2");
		return -1;
	}

	for(int i = 0; i < N_RX_CHANNELS; i++)
	{
		rx_mcdma_descr.rx_mcdma_channel_descr[i].enable = true;
		rx_mcdma_descr.rx_mcdma_channel_descr[i].addr = ((uint32_t)&mem_dest[512*i]);
		rx_mcdma_descr.rx_mcdma_channel_descr[i].len = 512*4;
	}
	for(int i = 0; i < N_TX_CHANNELS; i++)
	{
		tx_mcdma_descr.tx_mcdma_channel_descr[i].enable = true;
		tx_mcdma_descr.tx_mcdma_channel_descr[i].addr = ((uint32_t)&mem_source[512*i]);
		tx_mcdma_descr.tx_mcdma_channel_descr[i].len = 512*4;
	}

	if(SimpleRxMCDMA_Configure(0, &rx_mcdma_descr) != RX_MCDMA_OK || SimpleTxMCDMA_Configure(0, &tx_mcdma_descr) != TX_MCDMA_OK)
	{
		//xil_printf("MCDMA COnfiguration Error!\n\r");
		xil_printf("3");
		return -1;
	}

	if(SimpleRxMCDMA_Start(0) != RX_MCDMA_OK)
	{
		//xil_printf("RX MCDMA Start Error!\n\r");
		xil_printf("4");
		return -1;
	}
	if(SimpleTxMCDMA_Start(0)  != TX_MCDMA_OK)
	{
		//xil_printf("TX MCDMA Start Error!\n\r");
		xil_printf("5");
		return -1;
	}
	xil_printf("b");
	while(SimpleRxMCDMA_GetStatus(0) == RX_MCDMA_BUSY || SimpleTxMCDMA_GetStatus(0) == TX_MCDMA_BUSY);
	xil_printf("c");
	for(int i = 0; i < 2048; i++)
	{
		if(mem_dest[i] != mem_source[i])
		{
			xil_printf("6");
			//xil_printf("Data check Error: Index #%d, expected value: %d, obtained value: %d!\n\r",i,mem_source[i],mem_dest[i]);
			return -1;
		}
	}

	//xil_printf("MCDMA Test Success!!!\n\r");
	xil_printf("0");
	Xil_DCacheDisable();
	Xil_ICacheDisable();
	return 0;
}
